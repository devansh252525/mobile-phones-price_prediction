import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, root_mean_squared_error

# 1. DATA LOAD
try:
    df = pd.read_csv("mobile_phones.csv")
    print("Dataset successfully loaded!")
except FileNotFoundError:
    print("Error: 'mobile_phones.csv' file not found!")

# 2. CLEANING & PREPROCESSING
df.columns = df.columns.str.strip()

for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna("Unknown")
    else:
        df[col] = df[col].fillna(df[col].median())

# Safe numeric extraction for cameras
for cam in ['Rear Camera', 'Front Camera']:
    if cam in df.columns:
        df[cam] = df[cam].astype(str).str.extract(r'(\d+)').astype(float).fillna(0)

# Drop identifier columns to avoid overfitting
columns_to_drop = [col for col in ['Model', 'phone_id', 'Unnamed: 0'] if col in df.columns]
df = df.drop(columns=columns_to_drop, errors='ignore')

# Target column cleaning and training
if 'Prize' in df.columns:
    y = pd.to_numeric(df['Prize'].astype(str).str.replace(',', '', regex=False), errors='coerce').fillna(0)
    X = df.drop(columns=['Prize'])
    X = pd.get_dummies(X, drop_first=True)

    # 3. SPLIT DATA
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 4. TRAIN MODEL
    print("Training the Random Forest model...")
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train.values.ravel())

    # 5. EVALUATE
    predictions = model.predict(X_test)
    print(f"\nModel Evaluation Matrix:")
    print(f"Mean Absolute Error (MAE): Rs. {mean_absolute_error(y_test, predictions):.2f}")
    print(f"Root Mean Squared Error (RMSE): Rs. {root_mean_squared_error(y_test, predictions):.2f}")

    # 6. FEATURE IMPORTANCE CHART
    importances = model.feature_importances_
    importance_df = pd.DataFrame({'Feature': X.columns, 'Importance': importances})
    importance_df = importance_df.sort_values(by='Importance', ascending=False).head(10)
    print("\nTop Features Influencing Mobile Prize:\n")
    print(importance_df.to_string(index=False))

    plt.figure(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=importance_df, palette='viridis')
    plt.title('Top Key Features Influencing Mobile Phone Prices')
    plt.tight_layout()
    plt.savefig('feature_importance.png')
    print("1. Feature Importance chart saved!")

    # 7. ADVANCED BOXPLOT CHART (Mean vs Median with Outliers)
    plt.figure(figsize=(6, 5))
    sns.boxplot(y=y, showmeans=True, meanprops={"marker":"D", "markerfacecolor":"firebrick", "markeredgecolor":"black"})
    plt.title("Boxplot - Mean vs Median")
    plt.ylabel("Price")
    plt.tight_layout()
    plt.savefig('advanced_boxplot.png')
    print("2. Advanced Boxplot chart saved!")

    # 8. MEAN VS MEDIAN BAR CHART
    plt.figure(figsize=(5, 4))
    labels = ['Mean', 'Median']
    values = [y.mean(), y.median()]
    plt.bar(labels, values, color=['#B85042', '#2A9D8F'])
    plt.title("Mean vs Median - Right Skewed")
    plt.ylabel("Price")
    plt.tight_layout()
    plt.savefig('mean_vs_median.png')
    print("3. Mean vs Median bar chart saved!")

    # 9. HISTOGRAM (PRICE DISTRIBUTION WITH KDE)
    plt.figure(figsize=(10, 6))
    sns.histplot(y, kde=True, color="#B85042")
    plt.title("Distribution of Mobile Phone Prices")
    plt.xlabel("Price")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig('price_distribution.png')
    print("4. Histogram chart saved!")
    
    print("\n🏆 SUCCESS! ALL CHARTS GENERATED SUCCESSFULLY! 🏆")
else:
    print("Error: 'Prize' column not found in dataset.")